Ice Hut Improvement - Test Package
===================================

This package adds the Ice Hut improvement for frozen lake tiles.
Pioneers can build Ice Huts on ice lake tiles, providing +2 Food.

INSTALLATION:
1. Back up your existing files first!
2. Copy these files into your WTP mod folder, preserving paths:
   - CvGameCoreDLL.dll          -> Assets/CvGameCoreDLL.dll
   - CIV4ImprovementInfos.xml   -> Assets/XML/Terrain/CIV4ImprovementInfos.xml
   - CIV4BuildInfos.xml         -> Assets/XML/Units/CIV4BuildInfos.xml
   - CIV4UnitInfos.xml          -> Assets/XML/Units/CIV4UnitInfos.xml
   - XML_AUTO_UTF8_BuildInfo.xml -> Assets/XML/Text/XML_AUTO_UTF8_BuildInfo.xml
   - XML_AUTO_UTF8_ImprovementInfo.xml -> Assets/XML/Text/XML_AUTO_UTF8_ImprovementInfo.xml

TESTING:
- Use a map with ice lakes (e.g. Americas, Northwest Passage)
- Send a Pioneer to a frozen lake tile (not one covered by ice feature)
- The "Build Ice Hut" action should appear
- Land units should be able to walk onto frozen lake tiles

Built from branch: feature/ice-hut-improvement (Assert/debug build)
